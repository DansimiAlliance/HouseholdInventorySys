package householdapps;
import java.sql.SQLException;
import javax.swing.JFrame;


public class HouseHoldApps extends JFrame{

    public static void main(String[] args) throws SQLException {

            //InsertInventoryForm run = new InsertInventoryForm();
            HomePage run = new HomePage();
            //ViewPage run = new ViewPage();
            //UserHelp run = new UserHelp();
            //SoftDeveloper run = new SoftDeveloper();
            //SearchByName run = new SearchByName();
            //SearchByReceiptNo run = new SearchByReceiptNo();
            //listInventory run = new listInventory();
            //photoAlbumInventory run = new photoAlbumInventory();
            run.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            run.setVisible(true);
            run.pack();
            
    }
    
}
