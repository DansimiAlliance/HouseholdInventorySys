

package householdapps;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;

public class SearchByName extends javax.swing.JFrame {

    /**
     * Creates new form SearchByName
     */
    
        Connection con;
        Statement st;
        ResultSet rs, rs2;
        //PreparedStatement pst3;
        
    public SearchByName() {
        initComponents();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Query");
        setLocationByPlatform(true);
        setMaximumSize(new java.awt.Dimension(1000, 1000));
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMaximumSize(new java.awt.Dimension(500, 500));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Search for an Inventory by its Name");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All", "Antiques/Heirlooms", "Attic/Basement", "Automobile(s)/Boats", "Bathroom(s)", "Bedroom(s)", "Collectibles", "Crafting/Hobby", "Dining Room", "Documents", "Entryway/Mudroom", "Family History", "Family Room", "Garage/Shed", "Home (exterior/structure)", "Home Office", "Kitchen", "Laundry Room", "Living Room", "Master Bathroom", "Master Bedroom", "Nursery", "Off Site Storage", "Paperwork", "Pets", "Play Room", "Utilities" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(76, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        selected();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SearchByName.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SearchByName.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SearchByName.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SearchByName.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SearchByName().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables


public void selected ()
{    
 String in = jComboBox1.getSelectedItem().toString(); 
 String choice = jTextField1.getText();
        try {
            String details = null;
            String nametext;
            String menuName;
            String qtyitem;
            String retailer;
            String sn;
            String itemCost;
            String datePur;
            String info;
            String model;
            String receipt;
            String loco;
            String qty;
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventory", 
                    "root", "");
            st = con.createStatement();
                   
            //rs2 = st.executeQuery("SELECT * FROM form WHERE loco = '"+in+"'");
            rs = st.executeQuery("SELECT * FROM form WHERE itemName = '"+choice+"'");
            System.out.println(rs);
            
            while (rs.next()) 
            {
            
                nametext = rs.getString("itemName");
                menuName = rs.getString("manu");
                qtyitem = rs.getString("qtyitem");
                retailer = rs.getString("retailer");
                sn = rs.getString("serial");
                itemCost = rs.getString("cost");
                datePur = rs.getString("date");
                info = rs.getString("information");
                model = rs.getString("model");
                receipt = rs.getString("receiptno");
                loco = rs.getString("location");
                qty = rs.getString("qtyitem");
            
               
            details = "ITEM'S NAME:                       " + nametext;
            details += "\n MANUFACTURER'S NAME:              " + menuName;
            details += "\n ITEM'S MODEL:                     " + model;  
            details += "\n ITEM'S SERIAL NUMBER:             " + sn;
            details += "\n RETAILER'S PURCHASED FROM:        " + retailer;
            details += "\n PURCHASED COST:                   " + itemCost;
            details += "\n QUANTITY PURCHASED:               " + qtyitem;
            details += "\n DATE PURCHASED:                   " + datePur;
            details += "\n LOCATION OF ITEM AT HOME:         " + loco;
            details += "\n RECEIPT NUMBER:                   " + receipt;
            details += "\n \n ---------------------------------------- \n";
            details += "\n OTHER INFORMATION:\n" + info;    

            
            }
            

            
            Preview printPreview = new Preview(details);
            
            printPreview.setVisible(true);
            System.out.println(details);
            
           
            st.close();
            rs.close();
            con.close();
                    
        }
        catch ( Exception e ) 
		{
		e.printStackTrace();
                }
        
    
    
}

}
